-- =============================================================================
-- SSM v1.0 — Aligned SQL Server Schema (v2)
-- File   : db/SSM_schema_v2.sql
-- Date   : 2026-05-19
-- Purpose: Single canonical schema, aligned with templates/template_v2.xlsx.
--          Replaces the SSMS-exported db/script.sql (which lacked views,
--          indexes, CHECK constraints, users / sync_logs / audit_logs).
--
-- Run order : Run this ONCE against a fresh SSM_DB database.
--             Includes: tables + constraints + indexes + views + seed users.
-- =============================================================================

USE SSM_DB;
GO

-- =============================================================================
-- SECTION 1 : HIERARCHY TABLES
-- Natural-key PKs (NVARCHAR(10)) — keys are typed by survey staff in Excel.
--
-- IMPORTANT — Rooms table SCOPE
-- The `rooms` table holds ONLY rooms that contain a rack (e.g. Server Room,
-- Network Room, Comms Room). The web app exists to audit cameras and the
-- equipment that supports them; rooms without networking gear are not modeled.
-- This is intentional — keep the data set small and meaningful.
--
-- Cameras are NOT linked to a room — they live on a floor plan.
-- =============================================================================

CREATE TABLE sites (
    Site_ID       NVARCHAR(10)                          NOT NULL,
    name          NVARCHAR(100)                         NOT NULL,
    code          NVARCHAR(20)                          NULL,
    location      NVARCHAR(255)                         NULL,
    description   NVARCHAR(500)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_sites      PRIMARY KEY CLUSTERED (Site_ID),
    CONSTRAINT UQ_sites_code UNIQUE (code)
);
GO

CREATE TABLE buildings (
    Building_ID   NVARCHAR(10)                          NOT NULL,
    Site_ID       NVARCHAR(10)                          NOT NULL,
    name          NVARCHAR(100)                         NOT NULL,
    code          NVARCHAR(20)                          NULL,
    floor_count   INT          DEFAULT 1                NULL,
    description   NVARCHAR(500)                         NULL,
    image_data    NVARCHAR(MAX)                         NULL,
    image_type    NVARCHAR(50)                          NULL,
    note          NVARCHAR(500)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_buildings           PRIMARY KEY CLUSTERED (Building_ID),
    CONSTRAINT FK_buildings_site      FOREIGN KEY (Site_ID) REFERENCES sites(Site_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT UQ_buildings_code_site UNIQUE (Site_ID, code)
);
GO

CREATE TABLE floors (
    Floor_ID      NVARCHAR(10)                          NOT NULL,
    Site_ID       NVARCHAR(10)                          NOT NULL,
    Building_ID   NVARCHAR(10)                          NOT NULL,
    floor_number  INT                                   NULL,
    name          NVARCHAR(50)                          NULL,
    [function]    NVARCHAR(100)                         NULL,
    has_cctv      BIT          DEFAULT 0                NULL,
    image_data    NVARCHAR(MAX)                         NULL,
    image_type    NVARCHAR(50)                          NULL,
    note          NVARCHAR(500)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_floors          PRIMARY KEY CLUSTERED (Floor_ID),
    CONSTRAINT FK_floors_site     FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_floors_building FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);
GO

CREATE TABLE rooms (
    Room_ID       NVARCHAR(20)                          NOT NULL,
    Site_ID       NVARCHAR(10)                          NOT NULL,
    Building_ID   NVARCHAR(10)                          NOT NULL,
    Floor_ID      NVARCHAR(10)                          NOT NULL,
    name          NVARCHAR(100)                         NOT NULL,
    type          NVARCHAR(50)                          NULL,
    has_nvr       BIT          DEFAULT 0                NULL,
    has_sw        BIT          DEFAULT 0                NULL,
    -- physical dimensions (set by web later)
    width_m       DECIMAL(6,2)                          NULL,
    length_m      DECIMAL(6,2)                          NULL,
    -- floor-plan SVG box (set by web drag-drop)
    x             INT          DEFAULT 0                NULL,
    y             INT          DEFAULT 0                NULL,
    w             INT          DEFAULT 100              NULL,
    h             INT          DEFAULT 100              NULL,
    image_data    NVARCHAR(MAX)                         NULL,
    image_type    NVARCHAR(50)                          NULL,
    note          NVARCHAR(500)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_rooms          PRIMARY KEY CLUSTERED (Room_ID),
    CONSTRAINT FK_rooms_site     FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_rooms_building FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID),
    CONSTRAINT FK_rooms_floor    FOREIGN KEY (Floor_ID)    REFERENCES floors(Floor_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT CHK_rooms_type    CHECK (type IS NULL
                                    OR type IN ('server','network','office','power','other'))
);
GO

-- Natural-key PK: Rack_ID is typed by survey staff (e.g. 'BLD_1_F1_R1').
-- Matches template_v3.xlsx 5_Rack column "Rack_ID (PK)".
CREATE TABLE racks (
    Rack_ID       NVARCHAR(20)                          NOT NULL,
    Site_ID       NVARCHAR(10)                          NOT NULL,
    Building_ID   NVARCHAR(10)                          NOT NULL,
    Floor_ID      NVARCHAR(10)                          NOT NULL,
    Room_ID       NVARCHAR(20)                          NOT NULL,
    name          NVARCHAR(50)                          NOT NULL,
    total_units   INT          DEFAULT 42               NOT NULL,
    units_per_u   TINYINT      DEFAULT 3                NOT NULL,  -- micro-slots per U
    brand         NVARCHAR(50)                          NULL,
    model         NVARCHAR(50)                          NULL,
    max_power_w   INT                                   NULL,
    image_data    NVARCHAR(MAX)                         NULL,
    image_type    NVARCHAR(50)                          NULL,
    note          NVARCHAR(500)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_racks              PRIMARY KEY CLUSTERED (Rack_ID),
    CONSTRAINT FK_racks_site         FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_racks_building     FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID),
    CONSTRAINT FK_racks_floor        FOREIGN KEY (Floor_ID)    REFERENCES floors(Floor_ID),
    CONSTRAINT FK_racks_room         FOREIGN KEY (Room_ID)     REFERENCES rooms(Room_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT CHK_racks_total_units CHECK (total_units > 0),
    CONSTRAINT CHK_racks_units_per_u CHECK (units_per_u BETWEEN 1 AND 12)
);
GO

-- =============================================================================
-- SECTION 2 : DEVICE TABLES (3-way split)
-- u_position + u_subposition: micro-slot precision (Susan D2)
-- u_size:                     how many U the device occupies (multi-U servers)
-- =============================================================================

-- Natural-key PK: SW_ID (e.g. 'BLD_1_F1_R1_SW01'). Rack_ID NOT NULL —
-- standalone (non-rack) switches are added via web app later, not via import.
CREATE TABLE poe_switches (
    SW_ID           NVARCHAR(20)               NOT NULL,
    Site_ID         NVARCHAR(10)               NOT NULL,
    Building_ID     NVARCHAR(10)               NOT NULL,
    Floor_ID        NVARCHAR(10)               NOT NULL,
    Room_ID         NVARCHAR(20)               NOT NULL,
    Rack_ID         NVARCHAR(20)               NOT NULL,

    -- rack position (D2)
    u_position      INT                        NULL,
    u_subposition   TINYINT                    NULL,
    u_size          TINYINT      DEFAULT 1     NULL,  -- height in U

    -- identity
    device_name     NVARCHAR(100)              NOT NULL,
    switch_type     NVARCHAR(20)                NULL,  -- PoE / Non-PoE / Core / Aggregation
    brand           NVARCHAR(100)               NULL,
    model           NVARCHAR(100)               NULL,
    serial_no       NVARCHAR(100)               NULL,
    mac_address     NVARCHAR(20)                NULL,
    os_version      NVARCHAR(50)                NULL,

    -- network
    ip_address      NVARCHAR(20)                NULL,
    vlan_id         INT                         NULL,
    subnet_mask     NVARCHAR(20)                NULL,
    gateway         NVARCHAR(20)                NULL,

    -- PoE spec
    total_ports     INT                         NULL,
    poe_ports       INT                         NULL,
    poe_budget_w    INT                         NULL,
    poe_used_w      INT                         NULL,
    uplink_port     NVARCHAR(100)               NULL,

    -- status
    status          NVARCHAR(20)  DEFAULT N'unknown' NULL,
    fail_count      INT          DEFAULT 0     NULL,
    last_seen       DATETIME2(7)                NULL,
    notes           NVARCHAR(MAX)              NULL,
    created_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,

    CONSTRAINT PK_poe_switches    PRIMARY KEY CLUSTERED (SW_ID),
    -- filtered indexes allow multiple NULLs (SQL Server UNIQUE constraint does not)
    -- CONSTRAINT UQ_sw_serial / UQ_sw_mac created as filtered indexes after table creation
    CONSTRAINT UQ_sw_name         UNIQUE (device_name),
    CONSTRAINT CHK_sw_usubpos     CHECK  (u_subposition IS NULL OR u_subposition BETWEEN 1 AND 3),
    CONSTRAINT CHK_sw_status      CHECK  (status IN ('online','offline','warning','unknown')),
    CONSTRAINT CHK_sw_switch_type CHECK  (switch_type IS NULL
                                       OR switch_type IN ('PoE','Non-PoE','Core','Aggregation')),
    CONSTRAINT FK_sw_site         FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_sw_building     FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID),
    CONSTRAINT FK_sw_floor        FOREIGN KEY (Floor_ID)    REFERENCES floors(Floor_ID),
    CONSTRAINT FK_sw_room         FOREIGN KEY (Room_ID)     REFERENCES rooms(Room_ID),
    CONSTRAINT FK_sw_rack         FOREIGN KEY (Rack_ID)     REFERENCES racks(Rack_ID)
        ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

-- Natural-key PK: NVR_ID (e.g. 'BLD_1_F1_R1_NVR01'). Rack_ID NOT NULL.
-- Standalone (non-rack) NVRs are added via web app later.
CREATE TABLE nvrs (
    NVR_ID          NVARCHAR(20)               NOT NULL,
    Site_ID         NVARCHAR(10)               NOT NULL,
    Building_ID     NVARCHAR(10)               NOT NULL,
    Floor_ID        NVARCHAR(10)               NOT NULL,
    Room_ID         NVARCHAR(20)               NOT NULL,
    Rack_ID         NVARCHAR(20)               NOT NULL,

    u_position      INT                        NULL,
    u_subposition   TINYINT                    NULL,
    u_size          TINYINT      DEFAULT 1     NULL,

    device_name     NVARCHAR(100)              NOT NULL,
    brand           NVARCHAR(100)              NULL,
    model           NVARCHAR(100)              NULL,
    serial_no       NVARCHAR(100)              NULL,
    mac_address     NVARCHAR(20)               NULL,
    os_version      NVARCHAR(50)               NULL,    -- aka firmware

    -- NVR has 2 IPs: uplink + CCTV LAN
    ip_internet     NVARCHAR(20)               NULL,
    ip_cctv         NVARCHAR(20)               NULL,
    vlan_id         INT                        NULL,
    subnet_mask     NVARCHAR(20)               NULL,
    gateway         NVARCHAR(20)               NULL,

    -- recording spec
    total_channels  INT                        NULL,
    active_channels INT                        NULL,
    hdd_total_tb    DECIMAL(6,2)               NULL,
    hdd_used_pct    DECIMAL(5,2)               NULL,
    recording_res   NVARCHAR(20)               NULL,
    retention_days  INT                        NULL,
    record_status   NVARCHAR(20)               NULL,

    status          NVARCHAR(20) DEFAULT N'unknown' NULL,
    fail_count      INT          DEFAULT 0     NULL,
    last_seen       DATETIME2(7)               NULL,
    notes           NVARCHAR(MAX)              NULL,
    created_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,

    CONSTRAINT PK_nvrs             PRIMARY KEY CLUSTERED (NVR_ID),
    -- filtered indexes allow multiple NULLs (SQL Server UNIQUE constraint does not)
    -- CONSTRAINT UQ_nvr_serial / UQ_nvr_mac created as filtered indexes after table creation
    CONSTRAINT UQ_nvr_name         UNIQUE (device_name),
    CONSTRAINT CHK_nvr_usubpos     CHECK  (u_subposition IS NULL OR u_subposition BETWEEN 1 AND 3),
    CONSTRAINT CHK_nvr_status      CHECK  (status IN ('online','offline','warning','unknown')),
    CONSTRAINT CHK_nvr_hdd_pct     CHECK  (hdd_used_pct IS NULL OR hdd_used_pct BETWEEN 0 AND 100),
    CONSTRAINT CHK_nvr_rec_status  CHECK  (record_status IS NULL
                                        OR record_status IN ('normal','warning','error','stopped')),
    CONSTRAINT FK_nvr_site         FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_nvr_building     FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID),
    CONSTRAINT FK_nvr_floor        FOREIGN KEY (Floor_ID)    REFERENCES floors(Floor_ID),
    CONSTRAINT FK_nvr_room         FOREIGN KEY (Room_ID)     REFERENCES rooms(Room_ID),
    CONSTRAINT FK_nvr_rack         FOREIGN KEY (Rack_ID)     REFERENCES racks(Rack_ID)
        ON DELETE NO ACTION ON UPDATE CASCADE
);
GO

-- Cameras live on a FLOOR plan — NOT inside a Room or Rack.
-- The web app drag-drops camera icons onto the floor SVG, so map_x/map_y are
-- computed there. Survey staff only fill Site / Building / Floor.
CREATE TABLE cameras (
    id              INT          IDENTITY(1,1) NOT NULL,
    Site_ID         NVARCHAR(10)               NOT NULL,
    Building_ID     NVARCHAR(10)               NOT NULL,
    Floor_ID        NVARCHAR(10)               NOT NULL,

    device_name     NVARCHAR(100)              NOT NULL,
    brand           NVARCHAR(100)              NULL,
    model           NVARCHAR(100)              NULL,
    serial_no       NVARCHAR(100)              NULL,
    mac_address     NVARCHAR(100)              NULL,
    camera_type     NVARCHAR(50)               NULL,
    resolution      NVARCHAR(50)               NULL,
    firmware_version NVARCHAR(50)              NULL,

    ip_address      NVARCHAR(20)               NULL,
    vlan_id         INT                        NULL,
    subnet_mask     NVARCHAR(20)               NULL,
    gateway         NVARCHAR(20)               NULL,

    -- Natural key for the camera ('NVR9_CH1' = which NVR + channel records it).
    -- Nullable: camera may be installed but not yet wired to an NVR.
    NVR_CH          NVARCHAR(30)               NULL,

    -- PoE link: which switch + port powers this camera
    SW_ID           NVARCHAR(20)               NULL,
    poe_port_number INT                        NULL,

    -- NVR link: which NVR channel records this camera
    NVR_ID          NVARCHAR(20)               NULL,
    nvr_channel     INT                        NULL,

    install_location NVARCHAR(255)             NULL,   -- free-text: "เพดานทางเข้าหลัก"

    status          NVARCHAR(20) DEFAULT N'unknown' NULL,
    fail_count      INT          DEFAULT 0     NULL,
    last_seen       DATETIME2(7)               NULL,
    notes           NVARCHAR(MAX)              NULL,
    created_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at      DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,

    CONSTRAINT PK_cameras     PRIMARY KEY CLUSTERED (id),
    -- filtered indexes allow multiple NULLs (SQL Server UNIQUE constraint does not)
    -- CONSTRAINT UQ_cam_nvr_ch / UQ_cam_serial / UQ_cam_mac created as filtered indexes after table creation
    CONSTRAINT UQ_cam_name    UNIQUE (device_name),
    CONSTRAINT CHK_cam_status CHECK (status IN ('online','offline','warning','unknown')),
    CONSTRAINT FK_cam_site       FOREIGN KEY (Site_ID)     REFERENCES sites(Site_ID),
    CONSTRAINT FK_cam_building   FOREIGN KEY (Building_ID) REFERENCES buildings(Building_ID),
    CONSTRAINT FK_cam_floor      FOREIGN KEY (Floor_ID)    REFERENCES floors(Floor_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT FK_cam_poe_switch FOREIGN KEY (SW_ID)       REFERENCES poe_switches(SW_ID)
        ON DELETE SET NULL ON UPDATE NO ACTION,
    CONSTRAINT FK_cam_nvr        FOREIGN KEY (NVR_ID)      REFERENCES nvrs(NVR_ID)
        ON DELETE SET NULL ON UPDATE NO ACTION
);
GO

-- =============================================================================
-- SECTION 3 : AUTH + AUDIT + MONITORING
-- =============================================================================

CREATE TABLE users (
    User_ID       INT          IDENTITY(1,1)            NOT NULL,
    username      NVARCHAR(100)                         NOT NULL,
    pw_hash       NVARCHAR(255)                         NOT NULL,   -- bcrypt
    display_name  NVARCHAR(200)                         NULL,
    role          NVARCHAR(10)                          NOT NULL,
    is_active     BIT          DEFAULT 1                NOT NULL,
    last_login    DATETIME2(7)                          NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_users          PRIMARY KEY CLUSTERED (User_ID),
    CONSTRAINT UQ_users_username UNIQUE (username),
    CONSTRAINT CHK_users_role    CHECK  (role IN ('admin','user','viewer'))
);
GO

-- device_id is NVARCHAR(50) because devices have mixed PK types:
--   camera     → int (id)
--   nvr        → NVARCHAR (NVR_ID)
--   poe_switch → NVARCHAR (SW_ID)
CREATE TABLE sync_logs (
    id            INT          IDENTITY(1,1)            NOT NULL,
    device_type   NVARCHAR(20)                          NOT NULL,
    device_id     NVARCHAR(50)                          NOT NULL,
    synced_by     INT                                   NULL,
    sync_type     NVARCHAR(50)                          NULL,
    fields_updated NVARCHAR(MAX)                        NULL,  -- JSON
    status        NVARCHAR(20)                          NULL,
    message       NVARCHAR(MAX)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_sync_logs       PRIMARY KEY CLUSTERED (id),
    CONSTRAINT CHK_synclog_type   CHECK (device_type IN ('camera','nvr','poe_switch')),
    CONSTRAINT FK_synclog_user    FOREIGN KEY (synced_by) REFERENCES users(User_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);
GO

CREATE TABLE audit_logs (
    id            INT          IDENTITY(1,1)            NOT NULL,
    user_id       INT                                   NULL,
    action        NVARCHAR(20)                          NOT NULL,
    table_name    NVARCHAR(100)                         NOT NULL,
    record_id     NVARCHAR(50)                          NOT NULL,   -- accepts both int and natural keys
    old_value     NVARCHAR(MAX)                         NULL,
    new_value     NVARCHAR(MAX)                         NULL,
    created_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_audit_logs      PRIMARY KEY CLUSTERED (id),
    CONSTRAINT CHK_audit_action   CHECK (action IN ('INSERT','UPDATE','DELETE')),
    CONSTRAINT FK_auditlog_user   FOREIGN KEY (user_id) REFERENCES users(User_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);
GO

CREATE TABLE ping_logs (
    id            INT          IDENTITY(1,1)            NOT NULL,
    device_type   NVARCHAR(20)                          NOT NULL,
    device_id     NVARCHAR(50)                          NOT NULL,
    ip_address    NVARCHAR(20)                          NOT NULL,
    is_alive      BIT                                   NOT NULL,
    latency_ms    DECIMAL(8,2)                          NULL,
    pinged_at     DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_ping_logs       PRIMARY KEY CLUSTERED (id),
    CONSTRAINT CHK_pinglog_type   CHECK (device_type IN ('camera','nvr','poe_switch'))
);
GO

CREATE TABLE alert_logs (
    id            INT          IDENTITY(1,1)            NOT NULL,
    device_type   NVARCHAR(20)                          NOT NULL,
    device_id     NVARCHAR(50)                          NOT NULL,
    device_name   NVARCHAR(100)                         NOT NULL,
    brand         NVARCHAR(100)                         NULL,
    ip_address    NVARCHAR(20)                          NULL,
    site_name     NVARCHAR(100)                         NULL,
    building_name NVARCHAR(100)                         NULL,
    floor_name    NVARCHAR(50)                          NULL,
    room_name     NVARCHAR(100)                         NULL,
    poe_switch_name NVARCHAR(100)                       NULL,
    poe_port      INT                                   NULL,
    alert_type    NVARCHAR(20)                          NULL,
    message       NVARCHAR(500)                         NULL,
    webhook_sent  BIT          DEFAULT 0                NOT NULL,
    resolved_at   DATETIME2(7)                          NULL,
    alerted_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    updated_at    DATETIME2(7) DEFAULT SYSUTCDATETIME() NOT NULL,
    CONSTRAINT PK_alert_logs      PRIMARY KEY CLUSTERED (id),
    CONSTRAINT CHK_alert_dtype    CHECK (device_type IN ('camera','nvr','poe_switch')),
    CONSTRAINT CHK_alert_atype    CHECK (alert_type IS NULL
                                      OR alert_type IN ('offline','hdd_warning','hdd_full','back_online'))
);
GO

-- =============================================================================
-- SECTION 3b : FILTERED UNIQUE INDEXES (nullable unique columns)
-- SQL Server UNIQUE constraints reject multiple NULLs; filtered indexes do not.
-- =============================================================================

CREATE UNIQUE INDEX UQ_nvr_serial    ON nvrs         (serial_no)    WHERE serial_no    IS NOT NULL;
CREATE UNIQUE INDEX UQ_nvr_mac       ON nvrs         (mac_address)  WHERE mac_address  IS NOT NULL;
CREATE UNIQUE INDEX UQ_sw_serial     ON poe_switches (serial_no)    WHERE serial_no    IS NOT NULL;
CREATE UNIQUE INDEX UQ_sw_mac        ON poe_switches (mac_address)  WHERE mac_address  IS NOT NULL;
CREATE UNIQUE INDEX UQ_cam_serial    ON cameras      (serial_no)    WHERE serial_no    IS NOT NULL;
CREATE UNIQUE INDEX UQ_cam_mac       ON cameras      (mac_address)  WHERE mac_address  IS NOT NULL;
CREATE UNIQUE INDEX UQ_cam_nvr_ch    ON cameras      (NVR_CH)       WHERE NVR_CH       IS NOT NULL;
GO

-- =============================================================================
-- SECTION 4 : INDEXES (performance)
-- =============================================================================

CREATE INDEX IX_buildings_site    ON buildings    (Site_ID);
CREATE INDEX IX_floors_building   ON floors       (Building_ID);
CREATE INDEX IX_floors_site       ON floors       (Site_ID);
CREATE INDEX IX_rooms_floor       ON rooms        (Floor_ID);
CREATE INDEX IX_racks_room        ON racks        (Room_ID);

CREATE INDEX IX_cameras_floor     ON cameras      (Floor_ID);
CREATE INDEX IX_cameras_site      ON cameras      (Site_ID);
CREATE INDEX IX_cameras_poe       ON cameras      (SW_ID, poe_port_number);
CREATE INDEX IX_cameras_nvr       ON cameras      (NVR_ID, nvr_channel);
CREATE INDEX IX_cameras_nvr_ch    ON cameras      (NVR_CH);
CREATE INDEX IX_cameras_status    ON cameras      (status, fail_count);
CREATE INDEX IX_cameras_ip        ON cameras      (ip_address);

CREATE INDEX IX_nvrs_room         ON nvrs         (Room_ID);
CREATE INDEX IX_nvrs_rack_slot    ON nvrs         (Rack_ID, u_position, u_subposition);
CREATE INDEX IX_nvrs_status       ON nvrs         (status, fail_count);
CREATE INDEX IX_nvrs_ip_internet  ON nvrs         (ip_internet);
CREATE INDEX IX_nvrs_ip_cctv      ON nvrs         (ip_cctv);

CREATE INDEX IX_sw_room           ON poe_switches (Room_ID);
CREATE INDEX IX_sw_rack_slot      ON poe_switches (Rack_ID, u_position, u_subposition);
CREATE INDEX IX_sw_status         ON poe_switches (status, fail_count);
CREATE INDEX IX_sw_ip             ON poe_switches (ip_address);

CREATE INDEX IX_ping_device       ON ping_logs    (device_type, device_id, pinged_at);
CREATE INDEX IX_alert_device      ON alert_logs   (device_type, device_id, alerted_at);
CREATE INDEX IX_alert_unresolved  ON alert_logs   (resolved_at) WHERE resolved_at IS NULL;
CREATE INDEX IX_audit_table       ON audit_logs   (table_name, record_id, created_at);
CREATE INDEX IX_synclog_device    ON sync_logs    (device_type, device_id, created_at);
GO

-- =============================================================================
-- SECTION 5 : VIEWS
-- =============================================================================

CREATE OR ALTER VIEW vw_camera_full_path AS
-- The "CCTV Transaction" Susan drew on PDF page 2.
-- Cameras attach to a FLOOR (not a Room/Rack); web app places them on the floor SVG.
SELECT
    c.id                AS camera_id,
    c.device_name       AS camera_name,
    c.brand, c.model, c.serial_no, c.mac_address,
    c.ip_address, c.vlan_id, c.camera_type, c.resolution,
    c.install_location,
    c.status, c.fail_count, c.last_seen,
    s.Site_ID, s.name        AS site_name,
    b.Building_ID, b.name    AS building_name,
    f.Floor_ID, f.floor_number, f.name AS floor_name,
    c.NVR_CH,
    n.NVR_ID, n.device_name AS nvr_name, n.ip_internet AS nvr_ip_internet, n.ip_cctv AS nvr_ip_cctv,
    c.nvr_channel,
    sw.SW_ID, sw.device_name AS poe_switch_name, sw.ip_address AS poe_switch_ip,
    c.poe_port_number,
    c.created_at, c.updated_at
FROM       cameras       c
INNER JOIN sites         s  ON s.Site_ID     = c.Site_ID
INNER JOIN buildings     b  ON b.Building_ID = c.Building_ID
INNER JOIN floors        f  ON f.Floor_ID    = c.Floor_ID
LEFT  JOIN nvrs          n  ON n.NVR_ID      = c.NVR_ID
LEFT  JOIN poe_switches  sw ON sw.SW_ID      = c.SW_ID;
GO

CREATE OR ALTER VIEW vw_nvr_full_path AS
SELECT
    n.NVR_ID, n.device_name AS nvr_name,
    n.brand, n.model, n.serial_no, n.mac_address,
    n.ip_internet, n.ip_cctv, n.vlan_id, n.os_version,
    n.total_channels, n.active_channels, n.hdd_total_tb, n.hdd_used_pct,
    n.retention_days, n.record_status,
    n.u_position, n.u_subposition, n.u_size,
    n.status, n.fail_count, n.last_seen,
    s.Site_ID, s.name AS site_name,
    b.Building_ID, b.name AS building_name,
    f.Floor_ID, f.floor_number, f.name AS floor_name,
    r.Room_ID, r.name AS room_name,
    rk.Rack_ID, rk.name AS rack_name,
    n.created_at, n.updated_at
FROM       nvrs          n
INNER JOIN sites         s  ON s.Site_ID     = n.Site_ID
INNER JOIN buildings     b  ON b.Building_ID = n.Building_ID
INNER JOIN floors        f  ON f.Floor_ID    = n.Floor_ID
INNER JOIN rooms         r  ON r.Room_ID     = n.Room_ID
INNER JOIN racks         rk ON rk.Rack_ID    = n.Rack_ID;   -- INNER because Rack_ID NOT NULL
GO

CREATE OR ALTER VIEW vw_switch_full_path AS
SELECT
    sw.SW_ID, sw.device_name AS switch_name, sw.switch_type,
    sw.brand, sw.model, sw.serial_no, sw.mac_address,
    sw.ip_address, sw.vlan_id, sw.os_version,
    sw.total_ports, sw.poe_ports, sw.poe_budget_w, sw.poe_used_w, sw.uplink_port,
    sw.u_position, sw.u_subposition, sw.u_size,
    sw.status, sw.fail_count, sw.last_seen,
    s.Site_ID, s.name AS site_name,
    b.Building_ID, b.name AS building_name,
    f.Floor_ID, f.floor_number, f.name AS floor_name,
    r.Room_ID, r.name AS room_name,
    rk.Rack_ID, rk.name AS rack_name,
    sw.created_at, sw.updated_at
FROM       poe_switches  sw
INNER JOIN sites         s  ON s.Site_ID     = sw.Site_ID
INNER JOIN buildings     b  ON b.Building_ID = sw.Building_ID
INNER JOIN floors        f  ON f.Floor_ID    = sw.Floor_ID
INNER JOIN rooms         r  ON r.Room_ID     = sw.Room_ID
INNER JOIN racks         rk ON rk.Rack_ID    = sw.Rack_ID;
GO

CREATE OR ALTER VIEW vw_dashboard_summary AS
-- Per-site rollup counts. Uses scalar subqueries to avoid join cross-product.
SELECT
    s.Site_ID, s.code AS site_code, s.name AS site_name,

    (SELECT COUNT(*) FROM cameras      WHERE Site_ID = s.Site_ID)                            AS total_cameras,
    (SELECT COUNT(*) FROM cameras      WHERE Site_ID = s.Site_ID AND status = 'online')      AS cameras_online,
    (SELECT COUNT(*) FROM cameras      WHERE Site_ID = s.Site_ID AND status = 'offline')     AS cameras_offline,
    (SELECT COUNT(*) FROM cameras      WHERE Site_ID = s.Site_ID AND status = 'warning')     AS cameras_warning,

    (SELECT COUNT(*) FROM nvrs         WHERE Site_ID = s.Site_ID)                            AS total_nvrs,
    (SELECT COUNT(*) FROM nvrs         WHERE Site_ID = s.Site_ID AND status = 'offline')     AS nvrs_offline,
    (SELECT COUNT(*) FROM nvrs         WHERE Site_ID = s.Site_ID AND hdd_used_pct > 80)      AS nvrs_hdd_warning,

    (SELECT COUNT(*) FROM poe_switches WHERE Site_ID = s.Site_ID)                            AS total_switches,
    (SELECT COUNT(*) FROM poe_switches WHERE Site_ID = s.Site_ID AND status = 'offline')     AS switches_offline,

    (SELECT COUNT(*) FROM buildings    WHERE Site_ID = s.Site_ID)                            AS total_buildings,
    (SELECT COUNT(*) FROM floors       WHERE Site_ID = s.Site_ID)                            AS total_floors,
    (SELECT COUNT(*) FROM rooms        WHERE Site_ID = s.Site_ID)                            AS total_rooms,
    (SELECT COUNT(*) FROM racks        WHERE Site_ID = s.Site_ID)                            AS total_racks
FROM sites s;
GO

CREATE OR ALTER VIEW vw_unresolved_alerts AS
SELECT * FROM alert_logs WHERE resolved_at IS NULL;
GO

-- =============================================================================
-- SECTION 6 : SEED USERS (3 roles)
-- ⚠️  Replace bcrypt hashes before production. Plain-text in comments:
--       admin    →  Admin@SSM1
--       ssm_user →  User@SSM1
--       viewer   →  (logs in via Guest button — no password)
-- Generate fresh hashes with:
--       import bcrypt; print(bcrypt.hashpw(b"YourPwd", bcrypt.gensalt(12)).decode())
-- =============================================================================

IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'admin')
INSERT INTO users (username, pw_hash, display_name, role, is_active)
VALUES ('admin',
        '$2b$12$Ke7Qs3h2kPmNdJvF5Xg4O.eLwQ9ZrI8GaT0yC1HnUuVoB6MsWpXyi',
        N'Administrator', 'admin', 1);
GO

IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'ssm_user')
INSERT INTO users (username, pw_hash, display_name, role, is_active)
VALUES ('ssm_user',
        '$2b$12$Tr6Wm1jX4pNqKdHuG8Yk7O.dMvR2ZqI5FaS9xB0GnTtUp4LsVoWxi',
        N'SSM User', 'user', 1);
GO

IF NOT EXISTS (SELECT 1 FROM users WHERE username = 'viewer')
INSERT INTO users (username, pw_hash, display_name, role, is_active)
VALUES ('viewer',
        '$2b$12$PlaceholderHashForViewerAccountXXXXXXXXXXXXXXXXXXXXXXXX',
        N'Viewer (Guest)', 'viewer', 1);
GO

-- =============================================================================
-- END OF SSM_schema_v2.sql
-- Total: 13 tables, 5 views, 25+ indexes, all FK + CHECK + UNIQUE constraints.
-- =============================================================================
